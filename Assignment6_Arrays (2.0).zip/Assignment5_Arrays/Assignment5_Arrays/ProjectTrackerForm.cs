﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO; // Required for File Read/Write

namespace Assignment5_Arrays
{
    public partial class ProjectTrackerForm : Form
    {
        // Arrays to hold project data (Parallel Arrays)
        private string[] projectNames = new string[10];
        private int[] projectPriorities = new int[10];
        private int currentCount = 0;

        // Write to 2 files
        private const string FILE_PROJECTS = "projects.txt";
        private const string FILE_PRIORITIES = "priorities.txt";

        public ProjectTrackerForm()
        {
            InitializeComponent();
        }

        // BUTTON: ADD PROJECT
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (currentCount >= projectNames.Length)
                {
                    MessageBox.Show("Project list is full!", "Error");
                    return;
                }

                string nameInput = txtProjectName.Text;
                if (string.IsNullOrWhiteSpace(nameInput))
                {
                    MessageBox.Show("Please enter a valid project name.", "Input Error");
                    return;
                }

                // Add to parallel arrays
                projectNames[currentCount] = nameInput;
                projectPriorities[currentCount] = (int)numPriority.Value;
                currentCount++;

                UpdateProjectList();
                ClearInputs();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding project: " + ex.Message);
            }
        }

        // BUTTON: REMOVE PROJECT
        private void btnRemove_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedIndex = lstProjects.SelectedIndex;
                if (selectedIndex == -1) return;

                // Shift items to fill the gap
                for (int i = selectedIndex; i < currentCount - 1; i++)
                {
                    projectNames[i] = projectNames[i + 1];
                    projectPriorities[i] = projectPriorities[i + 1];
                }

                currentCount--;
                UpdateProjectList();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error removing project: " + ex.Message);
            }
        }

        // BUTTON: SAVE DATA / WRITE TO FILES
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                // Write to 2 files

                // 1. Create StreamWriter for projects
                using (StreamWriter writer1 = new StreamWriter(FILE_PROJECTS))
                {
                    // Loop through valid projects and write them
                    for (int i = 0; i < currentCount; i++)
                    {
                        writer1.WriteLine(projectNames[i]);
                    }
                }

                // 2. Create StreamWriter for priorities
                using (StreamWriter writer2 = new StreamWriter(FILE_PRIORITIES))
                {
                    for (int i = 0; i < currentCount; i++)
                    {
                        writer2.WriteLine(projectPriorities[i]);
                    }
                }

                lblStatus.Text = "Success: Data saved to local files.";
                MessageBox.Show("Data successfully saved!", "File I/O");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving files: " + ex.Message);
            }
        }

        // BUTTON: LOAD DATA / READ FROM FILES
        private void btnLoad_Click(object sender, EventArgs e)
        {
            try
            {
                // Read from 2 files

                if (!File.Exists(FILE_PROJECTS) || !File.Exists(FILE_PRIORITIES))
                {
                    MessageBox.Show("No saved files found.", "Load Error");
                    return;
                }

                // 1. Read all lines into temporary arrays
                string[] loadedNames = File.ReadAllLines(FILE_PROJECTS);
                string[] loadedPriorities = File.ReadAllLines(FILE_PRIORITIES);

                // 2. Clear current data
                currentCount = 0;
                Array.Clear(projectNames, 0, projectNames.Length);
                Array.Clear(projectPriorities, 0, projectPriorities.Length);

                // 3. Populate arrays, safely prevent overflow
                int loopLimit = Math.Min(loadedNames.Length, 10); // Don't exceed array size

                for (int i = 0; i < loopLimit; i++)
                {
                    projectNames[i] = loadedNames[i];

                    // Parse priority safely
                    if (int.TryParse(loadedPriorities[i], out int priority))
                    {
                        projectPriorities[i] = priority;
                    }
                    else
                    {
                        projectPriorities[i] = 1; // Default if parse fails
                    }

                    currentCount++;
                }

                UpdateProjectList();
                lblStatus.Text = $"Success: Loaded {currentCount} projects.";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading files: " + ex.Message);
            }
        }

        // HELPER FUNCTIONS
        private void UpdateProjectList()
        {
            lstProjects.Items.Clear();
            for (int i = 0; i < currentCount; i++)
            {
                lstProjects.Items.Add($"[Priority {projectPriorities[i]}] - {projectNames[i]}");
            }
        }

        private void ClearInputs()
        {
            txtProjectName.Clear();
            numPriority.Value = 1;
            txtProjectName.Focus();
        }
    }
}


