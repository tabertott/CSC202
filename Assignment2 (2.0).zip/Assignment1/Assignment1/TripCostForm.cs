// 1. DISABLE NULL WARNINGS 
// This prevents the compiler from complaining about uninitialized variables in this simple form.
#nullable disable 

using System;
using System.Drawing;
using System.Windows.Forms;

namespace Assignment1_GUI
{
    // Rename the form.
    // Using 'TripCostForm' instead of 'Form1'.
    public partial class TripCostForm : Form
    {
        // --- GUI COMPONENT DEFINITIONS ---
        // At least 6 GUI components
        // Using 8 components here (GroupBox, 3 Labels, 2 TextBoxes, 2 Buttons).
        private GroupBox grpTripDetails;
        private Label lblDistance;
        private TextBox txtDistance;
        private Label lblGasPrice;
        private TextBox txtGasPrice;
        private Button btnCalculate;
        private Button btnReset;
        private Label lblResult;

        // 3 variables of different types
        // 1. double: To store the MPG constant
        private const double MPG_CONSTANT = 18.5;

        public TripCostForm()
        {
            // Method calls our custom function to build the User Interface
            InitializeComponentCustom();
        }

        // Method to design the form
        private void InitializeComponentCustom()
        {
            // --- FORM SETUP ---
            // Customized form & UI improvement
            this.Text = "Trip Cost Estimator v2.0";
            this.Size = new Size(400, 380); // Slightly taller to fit error messages if needed
            this.StartPosition = FormStartPosition.CenterScreen; // Centers the app on launch
            this.BackColor = Color.WhiteSmoke; // Professional light gray background
            this.FormBorderStyle = FormBorderStyle.FixedDialog; // Prevents resizing
            this.MaximizeBox = false; // Disables the maximize button

            // --- COMPONENT 1: GROUPBOX (Container) ---
            this.grpTripDetails = new GroupBox();
            this.grpTripDetails.Text = "Trip Details";
            this.grpTripDetails.Location = new Point(20, 20);
            this.grpTripDetails.Size = new Size(340, 150);
            this.grpTripDetails.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);

            // --- COMPONENT 2: LABEL (Distance Prompt) ---
            this.lblDistance = new Label();
            this.lblDistance.Text = "Distance (miles):";
            this.lblDistance.Location = new Point(20, 40);
            this.lblDistance.AutoSize = true;

            // --- COMPONENT 3: TEXTBOX (Distance Input) ---
            this.txtDistance = new TextBox();
            this.txtDistance.Location = new Point(150, 37);
            this.txtDistance.Size = new Size(150, 23);
            // Adding a tool tip text placeholder effect isn't native, but we handle empty inputs in logic.

            // --- COMPONENT 4: LABEL (Gas Price Prompt) ---
            this.lblGasPrice = new Label();
            this.lblGasPrice.Text = "Gas Price ($/gal):";
            this.lblGasPrice.Location = new Point(20, 80);
            this.lblGasPrice.AutoSize = true;

            // --- COMPONENT 5: TEXTBOX (Gas Price Input) ---
            this.txtGasPrice = new TextBox();
            this.txtGasPrice.Location = new Point(150, 77);
            this.txtGasPrice.Size = new Size(150, 23);

            // Add inputs to the GroupBox
            this.grpTripDetails.Controls.Add(this.lblDistance);
            this.grpTripDetails.Controls.Add(this.txtDistance);
            this.grpTripDetails.Controls.Add(this.lblGasPrice);
            this.grpTripDetails.Controls.Add(this.txtGasPrice);

            // --- COMPONENT 6: BUTTON (Calculate) ---
            // 2 functional buttons
            this.btnCalculate = new Button();
            this.btnCalculate.Text = "Calculate Cost";
            this.btnCalculate.Location = new Point(20, 190);
            this.btnCalculate.Size = new Size(160, 40);
            this.btnCalculate.BackColor = Color.LightSteelBlue; // Custom color for better UX
            this.btnCalculate.FlatStyle = FlatStyle.Flat;
            this.btnCalculate.Click += new EventHandler(this.btnCalculate_Click);

            // --- COMPONENT 7: BUTTON (Reset) ---
            this.btnReset = new Button();
            this.btnReset.Text = "Reset";
            this.btnReset.Location = new Point(200, 190);
            this.btnReset.Size = new Size(160, 40);
            this.btnReset.BackColor = Color.LightSalmon; // Different color to distinguish action
            this.btnReset.FlatStyle = FlatStyle.Flat;
            this.btnReset.Click += new EventHandler(this.btnReset_Click);

            // --- COMPONENT 8: LABEL RESULT ---
            // Display at least 1 variable's value on the form
            this.lblResult = new Label();
            this.lblResult.Text = "Estimated Cost: $0.00";
            this.lblResult.Location = new Point(20, 250);
            this.lblResult.AutoSize = false;
            this.lblResult.Size = new Size(340, 60); // Taller for multi-line text
            this.lblResult.TextAlign = ContentAlignment.MiddleCenter;
            this.lblResult.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            this.lblResult.ForeColor = Color.DarkSlateGray;

            // Add main controls to Form
            this.Controls.Add(this.grpTripDetails);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.lblResult);
        }

        // --- EVENT HANDLERS / Logic ---

        // Event for the Calculate Button
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Create 3 variables of different types
            // Variable Type 1: double (for math)
            double distance = 0.0;
            double price = 0.0;
            double totalCost = 0.0;

            // Variable Type 2: bool (for logic checks)
            bool isValidInput = false;

            // Variable Type 3: string (for messaging)
            string resultMessage = "";

            // 2 sets of conditional (if/else) statements

            // --- CONDITIONAL SET 1: Input Validation ---
            // Using double.TryParse to convert text to numbers without crashing.
            if (double.TryParse(txtDistance.Text, out distance) && double.TryParse(txtGasPrice.Text, out price))
            {
                // If parsing works, set boolean flag to true
                isValidInput = true;
            }
            else
            {
                // If parsing fails (user typed "abc"), valid is false
                isValidInput = false;
                resultMessage = "Error: Please enter numbers only.";
            }

            // --- CONDITIONAL SET 2: Logic Validation & Calculation ---
            if (isValidInput)
            {
                // Ensure numbers are not negative
                if (distance > 0 && price > 0)
                {
                    // Calculation: (Distance / MPG) * Gas Price
                    totalCost = (distance / MPG_CONSTANT) * price;

                    // Formatting the output to currency format ("C2")
                    // Display variable on form
                    lblResult.Text = $"Estimated Cost: {totalCost.ToString("C2")}";
                    lblResult.ForeColor = Color.DarkGreen; // Green for success
                }
                else
                {
                    // Specific feedback for negative numbers
                    lblResult.Text = "Error: Values must be positive.";
                    lblResult.ForeColor = Color.Red; // UX Improvement: Red for error
                }
            }
            else
            {
                // Display the error message from the first conditional block
                lblResult.Text = resultMessage;
                lblResult.ForeColor = Color.Red;
            }
        }

        // Event for the Reset Button
        private void btnReset_Click(object sender, EventArgs e)
        {
            // Clear the text boxes
            txtDistance.Text = "";
            txtGasPrice.Text = "";

            // Reset the result label to default state
            lblResult.Text = "Estimated Cost: $0.00";
            lblResult.ForeColor = Color.DarkSlateGray;

            // Set focus back to the first box so user can type immediately
            txtDistance.Focus();
        }
    }
}


