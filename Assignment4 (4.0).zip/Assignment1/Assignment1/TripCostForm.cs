// 1. DISABLE NULL WARNINGS 
#nullable disable 

using System;
using System.Drawing;
using System.Collections.Generic; // Required for using Lists
using System.Windows.Forms;

namespace Assignment1_GUI
{
    // RUBRIC REQUIREMENT: "Rename the form."
    public partial class TripCostForm : Form
    {
        // --- DATA STRUCTURES ---
        // RUBRIC REQUIREMENT: "Use 1 for or while loop" (We need a list to loop through)
        private List<double> tripCosts = new List<double>();

        // --- GUI COMPONENTS ---
        // RUBRIC REQUIREMENT: "At least 6 GUI components"
        private GroupBox grpTripDetails;
        private Label lblDistance;
        private TextBox txtDistance;
        private Label lblGasPrice;
        private TextBox txtGasPrice;
        private Label lblEfficiency;
        private TextBox txtEfficiency;
        private Button btnLogTrip;
        private Button btnClear;
        private ListBox lstHistory; // New component to show the loop in action
        private Label lblTotalSummary;

        public TripCostForm()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            // --- FORM SETUP ---
            this.Text = "Trip Expense Logger v4.0";
            this.Size = new Size(500, 550);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.WhiteSmoke;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // --- INPUT GROUP ---
            this.grpTripDetails = new GroupBox();
            this.grpTripDetails.Text = "New Trip Entry";
            this.grpTripDetails.Location = new Point(20, 20);
            this.grpTripDetails.Size = new Size(440, 150);
            this.grpTripDetails.Font = new Font("Segoe UI", 10F);

            // Inputs
            this.lblDistance = new Label() { Text = "Distance (miles):", Location = new Point(20, 30), AutoSize = true };
            this.txtDistance = new TextBox() { Location = new Point(180, 27), Size = new Size(150, 25) };

            this.lblGasPrice = new Label() { Text = "Gas Price ($/gal):", Location = new Point(20, 70), AutoSize = true };
            this.txtGasPrice = new TextBox() { Location = new Point(180, 67), Size = new Size(150, 25) };

            this.lblEfficiency = new Label() { Text = "Vehicle MPG:", Location = new Point(20, 110), AutoSize = true };
            this.txtEfficiency = new TextBox() { Location = new Point(180, 107), Size = new Size(150, 25), Text = "25.0" };

            this.grpTripDetails.Controls.Add(this.lblDistance);
            this.grpTripDetails.Controls.Add(this.txtDistance);
            this.grpTripDetails.Controls.Add(this.lblGasPrice);
            this.grpTripDetails.Controls.Add(this.txtGasPrice);
            this.grpTripDetails.Controls.Add(this.lblEfficiency);
            this.grpTripDetails.Controls.Add(this.txtEfficiency);

            // --- BUTTONS ---
            // RUBRIC REQUIREMENT: "Create at least 2 buttons"
            this.btnLogTrip = new Button();
            this.btnLogTrip.Text = "Calculate & Log Trip";
            this.btnLogTrip.Location = new Point(20, 190);
            this.btnLogTrip.Size = new Size(210, 50);
            this.btnLogTrip.BackColor = Color.LightSteelBlue;
            this.btnLogTrip.FlatStyle = FlatStyle.Flat;
            this.btnLogTrip.Click += new EventHandler(this.btnLogTrip_Click);

            this.btnClear = new Button();
            this.btnClear.Text = "Clear History";
            this.btnClear.Location = new Point(250, 190);
            this.btnClear.Size = new Size(210, 50);
            this.btnClear.BackColor = Color.LightSalmon;
            this.btnClear.FlatStyle = FlatStyle.Flat;
            this.btnClear.Click += new EventHandler(this.btnClear_Click);

            // RUBRIC REQUIREMENT: "Turn GUI elements on and off"
            this.btnClear.Enabled = false; // Disabled by default until we have data

            // --- OUTPUTS ---
            this.lstHistory = new ListBox();
            this.lstHistory.Location = new Point(20, 260);
            this.lstHistory.Size = new Size(440, 150);
            this.lstHistory.Font = new Font("Consolas", 9F);

            this.lblTotalSummary = new Label();
            this.lblTotalSummary.Text = "Total Expenses: $0.00";
            this.lblTotalSummary.Location = new Point(20, 430);
            this.lblTotalSummary.AutoSize = false;
            this.lblTotalSummary.Size = new Size(440, 50);
            this.lblTotalSummary.TextAlign = ContentAlignment.MiddleCenter;
            this.lblTotalSummary.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            this.lblTotalSummary.ForeColor = Color.DarkSlateGray;

            this.Controls.Add(this.grpTripDetails);
            this.Controls.Add(this.btnLogTrip);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.lstHistory);
            this.Controls.Add(this.lblTotalSummary);
        }

        // --- EVENT HANDLERS ---

        private void btnLogTrip_Click(object sender, EventArgs e)
        {
            // Call our custom function 1
            ProcessTripData();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Call our custom function 2
            ResetApplication();
        }

        // --- CUSTOM FUNCTIONS (RUBRIC: "Write and call at least 2 functions") ---

        /// <summary>
        /// Function 1: Handles the logic for validating, calculating, and logging a trip.
        /// Demonstrates Exceptions and Conditionals.
        /// </summary>
        private void ProcessTripData()
        {
            // RUBRIC REQUIREMENT: "Create/handle 2 different exceptions"
            try
            {
                // Attempt to parse inputs
                double dist = double.Parse(txtDistance.Text);
                double price = double.Parse(txtGasPrice.Text);
                double mpg = double.Parse(txtEfficiency.Text);

                // RUBRIC REQUIREMENT: "2 conditional statement blocks"
                // Block 1: Logical Validation
                if (dist < 0 || price < 0 || mpg < 0)
                {
                    MessageBox.Show("Values cannot be negative.", "Input Error");
                    return;
                }

                // Block 2: Check for Division by Zero specific case
                if (mpg == 0)
                {
                    // Manually throwing an exception to be caught below
                    throw new DivideByZeroException();
                }

                // Calculation
                double cost = (dist / mpg) * price;

                // Add to our list and GUI
                tripCosts.Add(cost);
                lstHistory.Items.Add($"Trip: {dist}mi @ {mpg}mpg = {cost:C2}");

                // Update the total (calls the Loop function)
                UpdateTotalExpenses();

                // RUBRIC REQUIREMENT: "Turn GUI elements on"
                // Now that we have data, enable the Clear button
                btnClear.Enabled = true;
                btnClear.BackColor = Color.LightSalmon; // Visual cue
            }
            catch (FormatException ex)
            {
                // Exception 1: User typed letters instead of numbers
                MessageBox.Show("Please enter valid numbers only.", "Format Error");
            }
            catch (DivideByZeroException ex)
            {
                // Exception 2: User tried to divide by zero (MPG = 0)
                MessageBox.Show("MPG cannot be zero. Physics forbids it!", "Math Error");
            }
        }

        /// <summary>
        /// Function 2: Resets the application state.
        /// Demonstrates GUI manipulation.
        /// </summary>
        private void ResetApplication()
        {
            // Clear Data
            tripCosts.Clear();
            lstHistory.Items.Clear();

            // Clear Inputs
            txtDistance.Clear();
            txtGasPrice.Clear();
            lblTotalSummary.Text = "Total Expenses: $0.00";

            // RUBRIC REQUIREMENT: "Turn GUI elements off"
            btnClear.Enabled = false;
            btnClear.BackColor = Color.LightGray; // Grey out the button

            txtDistance.Focus();
        }

        /// <summary>
        /// Helper Function: Uses a loop to sum up costs.
        /// </summary>
        private void UpdateTotalExpenses()
        {
            double total = 0;

            // RUBRIC REQUIREMENT: "Use 1 for or while loop"
            foreach (double tripCost in tripCosts)
            {
                total += tripCost; // Accumulate the total
            }

            lblTotalSummary.Text = $"Total Expenses: {total:C2}";
        }
    }
}


