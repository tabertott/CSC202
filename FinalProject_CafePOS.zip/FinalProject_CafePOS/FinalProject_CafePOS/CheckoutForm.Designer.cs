﻿namespace FinalProject_CafePOS
{
    partial class CheckoutForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblDue = new System.Windows.Forms.Label();
            this.lblPrompt = new System.Windows.Forms.Label();
            this.txtPayment = new System.Windows.Forms.TextBox();
            this.btnPay = new System.Windows.Forms.Button();
            this.lblChange = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblDue
            // 
            this.lblDue.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblDue.ForeColor = System.Drawing.Color.DarkRed;
            this.lblDue.Location = new System.Drawing.Point(30, 20);
            this.lblDue.Name = "lblDue";
            this.lblDue.Size = new System.Drawing.Size(320, 30);
            this.lblDue.TabIndex = 0;
            this.lblDue.Text = "Amount Due: $0.00";
            this.lblDue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPrompt
            // 
            this.lblPrompt.AutoSize = true;
            this.lblPrompt.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblPrompt.Location = new System.Drawing.Point(30, 75);
            this.lblPrompt.Name = "lblPrompt";
            this.lblPrompt.Size = new System.Drawing.Size(155, 19);
            this.lblPrompt.TabIndex = 1;
            this.lblPrompt.Text = "Enter Payment Amount:";
            // 
            // txtPayment
            // 
            this.txtPayment.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtPayment.Location = new System.Drawing.Point(200, 72);
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.Size = new System.Drawing.Size(150, 25);
            this.txtPayment.TabIndex = 2;
            // 
            // btnPay
            // 
            this.btnPay.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnPay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPay.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnPay.ForeColor = System.Drawing.Color.White;
            this.btnPay.Location = new System.Drawing.Point(30, 120);
            this.btnPay.Name = "btnPay";
            this.btnPay.Size = new System.Drawing.Size(320, 45);
            this.btnPay.TabIndex = 3;
            this.btnPay.Text = "Submit Payment";
            this.btnPay.UseVisualStyleBackColor = false;
            this.btnPay.Click += new System.EventHandler(this.btnPay_Click);
            // 
            // lblChange
            // 
            this.lblChange.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblChange.Location = new System.Drawing.Point(30, 180);
            this.lblChange.Name = "lblChange";
            this.lblChange.Size = new System.Drawing.Size(320, 30);
            this.lblChange.TabIndex = 4;
            this.lblChange.Text = "Change: $0.00";
            this.lblChange.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.LightGray;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnClose.Location = new System.Drawing.Point(120, 230);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(140, 35);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "Close & Return";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // CheckoutForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(384, 291);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblChange);
            this.Controls.Add(this.btnPay);
            this.Controls.Add(this.txtPayment);
            this.Controls.Add(this.lblPrompt);
            this.Controls.Add(this.lblDue);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "CheckoutForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Checkout & Payment";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDue;
        private System.Windows.Forms.Label lblPrompt;
        private System.Windows.Forms.TextBox txtPayment;
        private System.Windows.Forms.Button btnPay;
        private System.Windows.Forms.Label lblChange;
        private System.Windows.Forms.Button btnClose;
    }
}


