﻿using System;
using System.Collections.Generic;
using System.IO; // Required for I/O
using System.Windows.Forms;

namespace FinalProject_CafePOS
{
    public partial class CheckoutForm : Form
    {
        // Variables passed from MainForm
        private double finalTotal;
        private List<string> purchasedItems;

        // 5th Variable Type: decimal 
        private decimal paymentReceived = 0.0m;

        // Constructor accepting parameters to link the forms
        public CheckoutForm(double total, List<string> items)
        {
            InitializeComponent();
            this.Text = "Checkout & Payment";
            this.StartPosition = FormStartPosition.CenterParent;

            // Store passed data
            finalTotal = total;
            purchasedItems = items;

            // Display amount due
            lblDue.Text = $"Amount Due: {finalTotal:C2}";
        }

        // --- 2 instances of event handling (2/2) ---
        private void btnPay_Click(object sender, EventArgs e)
        {
            // Function Call (4/5)
            ProcessPayment();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close(); // Returns to MainForm
        }

        // --- at least 5 functions (4, 5) ---

        /// <summary>
        /// Function 4 validates the payment input and processes the transaction.
        /// </summary>
        private void ProcessPayment()
        {
            // --- 2 instances of exception handling (1/2) ---
            try
            {
                // parse the user's text into a decimal number
                paymentReceived = decimal.Parse(txtPayment.Text);
                decimal finalTotalDec = (decimal)finalTotal;

                // --- Decision Logic (2/2) ---
                if (paymentReceived >= finalTotalDec)
                {
                    decimal change = paymentReceived - finalTotalDec;
                    lblChange.Text = $"Change: {change:C2}";
                    lblChange.ForeColor = System.Drawing.Color.Green;

                    MessageBox.Show("Payment Successful! Generating receipt...", "Success");

                    // Function Call (5/5)
                    GenerateReceiptFile(paymentReceived, change);

                    btnPay.Enabled = false; // Prevent double charging
                }
                else
                {
                    MessageBox.Show("Insufficient funds. Please enter a valid amount.", "Declined");
                }
            }
            catch (FormatException)
            {
                // Exception handled: User entered letters or symbols instead of numbers
                MessageBox.Show("Error: Please enter numbers only for payment.", "Input Error");
                txtPayment.Clear();
                txtPayment.Focus();
            }
        }

        /// <summary>
        /// Function 5: Writes the transaction data to a text file.
        /// </summary>
        private void GenerateReceiptFile(decimal payment, decimal change)
        {
            // --- 2 instances of exception handling (2/2) ---
            try
            {
                // --- Read and write to at least 1 file ---
                string filePath = "CafeReceipt.txt";

                // StreamWriter with 'true' appends to the file instead of overwriting
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("--- CYBER CAFE RECEIPT ---");
                    writer.WriteLine($"Date: {DateTime.Now}");

                    foreach (string item in purchasedItems)
                    {
                        writer.WriteLine($"- {item}");
                    }

                    writer.WriteLine($"Total: {finalTotal:C2}");
                    writer.WriteLine($"Paid: {payment:C2}");
                    writer.WriteLine($"Change: {change:C2}");
                    writer.WriteLine("--------------------------\n");
                }
            }
            catch (IOException ex)
            {
                // Exception handler: File is locked or system lacks permissions
                MessageBox.Show($"File Write Error: Could not save receipt. Details: {ex.Message}", "System Error");
            }
        }
    }
}

