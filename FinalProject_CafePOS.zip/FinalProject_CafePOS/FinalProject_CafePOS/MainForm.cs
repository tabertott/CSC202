﻿using System;
using System.Collections.Generic; // Required for lists
using System.Windows.Forms;

namespace FinalProject_CafePOS
{
    public partial class MainForm : Form
    {
        // --- 5 Variables of different types ---
        // 1. List<string> (Reference Type / List) - Holds item names
        private List<string> cartItems = new List<string>();

        // 2. List<double> (Reference Type / List) - Holds item prices
        private List<double> cartPrices = new List<double>();

        // 3. double (Value Type) - Running total
        private double orderTotal = 0.00;

        // 4. int (Value Type) - Counts total items
        private int itemCount = 0;

        // 5. bool (Value Type) - Tracks if cart is empty
        private bool isCartEmpty = true;

        public MainForm()
        {
            InitializeComponent();
            this.Text = "Cyber Cafe POS - Order Screen";
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        // --- 2 instances of event handling (1/2) ---
        private void btnCoffee_Click(object sender, EventArgs e)
        {
            // Function Call (1/5)
            AddToCart("Black Coffee", 2.50);
        }

        private void btnPastry_Click(object sender, EventArgs e)
        {
            // Function Call (2/5)
            AddToCart("Pastry", 4.00);
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            // Logic (1/2)
            if (isCartEmpty)
            {
                MessageBox.Show("Cart is empty! Please add items first.", "Notice");
                return;
            }

            // --- 2 forms linked to each other ---
            // Pass the total and the item list to the second form via its constructor
            CheckoutForm checkoutParams = new CheckoutForm(orderTotal, cartItems);

            // Show the second form as a dialog and stops interaction with main form until closed
            checkoutParams.ShowDialog();

            // When checkout closes, clear the cart for the next customer
            ClearCart();
        }

        // --- Create at least 5 functions (1, 2, 3) ---

        /// <summary>
        /// Function 1: Adds an item to the parallel lists and updates state.
        /// </summary>
        private void AddToCart(string itemName, double itemPrice)
        {
            cartItems.Add(itemName);
            cartPrices.Add(itemPrice);
            itemCount++;
            isCartEmpty = false;

            UpdateUI();
        }

        /// <summary>
        /// Function 2: Calculates total and updates the labels and listbox.
        /// </summary>
        private void UpdateUI()
        {
            lstCart.Items.Clear();
            orderTotal = 0; // Reset total before recalculating

            // 1 Loop
            // Loop through the arrays to calculate the total and display items
            for (int i = 0; i < cartItems.Count; i++)
            {
                lstCart.Items.Add($"{cartItems[i]} - {cartPrices[i]:C2}");
                orderTotal += cartPrices[i];
            }

            lblTotal.Text = $"Total ({itemCount} items): {orderTotal:C2}";
        }

        /// <summary>
        /// Function 3: Resets the application for the next transaction.
        /// </summary>
        private void ClearCart()
        {
            cartItems.Clear();
            cartPrices.Clear();
            orderTotal = 0;
            itemCount = 0;
            isCartEmpty = true;
            UpdateUI();
        }
    }
}

