// 1. DISABLE NULL WARNINGS 
#nullable disable 

using System;
using System.Drawing;
using System.Windows.Forms;

namespace Assignment1_GUI
{
    // Rename the form
    public partial class TripCostForm : Form
    {
        // --- GUI COMPONENT DEFINITIONS ---
        // At least 6 GUI components" (10)
        private GroupBox grpTripDetails;
        private Label lblDistance;
        private TextBox txtDistance;
        private Label lblGasPrice;
        private TextBox txtGasPrice;
        private Label lblEfficiency;
        private TextBox txtEfficiency; // New input for MPG
        private Button btnCalculateUSD;
        private Button btnConvertMetric;
        private Label lblResult;

        public TripCostForm()
        {
            // Build the UI
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            // --- FORM SETUP ---
            // Customized form
            this.Text = "Trip Planner Pro v3.0";
            this.Size = new Size(450, 450);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.AliceBlue; // Updated Color Scheme
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // --- COMPONENT 1: GROUPBOX ---
            this.grpTripDetails = new GroupBox();
            this.grpTripDetails.Text = "Trip Data Input";
            this.grpTripDetails.Location = new Point(20, 20);
            this.grpTripDetails.Size = new Size(390, 180);
            this.grpTripDetails.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);

            // --- COMPONENT 2 & 3: Distance ---
            this.lblDistance = new Label();
            this.lblDistance.Text = "Distance (miles):";
            this.lblDistance.Location = new Point(20, 40);
            this.lblDistance.AutoSize = true;

            this.txtDistance = new TextBox();
            this.txtDistance.Location = new Point(180, 37);
            this.txtDistance.Size = new Size(150, 25);

            // --- COMPONENT 4 & 5: Gas Price ---
            this.lblGasPrice = new Label();
            this.lblGasPrice.Text = "Gas Price ($/gal):";
            this.lblGasPrice.Location = new Point(20, 80);
            this.lblGasPrice.AutoSize = true;

            this.txtGasPrice = new TextBox();
            this.txtGasPrice.Location = new Point(180, 77);
            this.txtGasPrice.Size = new Size(150, 25);

            // --- COMPONENT 6 & 7: Efficiency (Assignment 3) ---
            this.lblEfficiency = new Label();
            this.lblEfficiency.Text = "Vehicle MPG:";
            this.lblEfficiency.Location = new Point(20, 120);
            this.lblEfficiency.AutoSize = true;

            this.txtEfficiency = new TextBox();
            this.txtEfficiency.Location = new Point(180, 117);
            this.txtEfficiency.Size = new Size(150, 25);
            this.txtEfficiency.Text = "25.0"; // Default value

            // Add inputs to GroupBox
            this.grpTripDetails.Controls.Add(this.lblDistance);
            this.grpTripDetails.Controls.Add(this.txtDistance);
            this.grpTripDetails.Controls.Add(this.lblGasPrice);
            this.grpTripDetails.Controls.Add(this.txtGasPrice);
            this.grpTripDetails.Controls.Add(this.lblEfficiency);
            this.grpTripDetails.Controls.Add(this.txtEfficiency);

            // --- COMPONENT 8: Primary Button ---
            this.btnCalculateUSD = new Button();
            this.btnCalculateUSD.Text = "Calculate Trip Cost ($)";
            this.btnCalculateUSD.Location = new Point(20, 220);
            this.btnCalculateUSD.Size = new Size(190, 50);
            this.btnCalculateUSD.BackColor = Color.LightSteelBlue;
            this.btnCalculateUSD.FlatStyle = FlatStyle.Flat;
            this.btnCalculateUSD.Click += new EventHandler(this.btnCalculateUSD_Click);

            // --- COMPONENT 9: Secondary Button ---
            this.btnConvertMetric = new Button();
            this.btnConvertMetric.Text = "Convert to Metric (km/L)";
            this.btnConvertMetric.Location = new Point(220, 220);
            this.btnConvertMetric.Size = new Size(190, 50);
            this.btnConvertMetric.BackColor = Color.LightGray;
            this.btnConvertMetric.FlatStyle = FlatStyle.Flat;
            this.btnConvertMetric.Click += new EventHandler(this.btnConvertMetric_Click);

            // --- COMPONENT 10: Result Label ---
            this.lblResult = new Label();
            this.lblResult.Text = "Ready to Calculate...";
            this.lblResult.Location = new Point(20, 290);
            this.lblResult.AutoSize = false;
            this.lblResult.Size = new Size(390, 100);
            this.lblResult.TextAlign = ContentAlignment.TopCenter;
            this.lblResult.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            this.lblResult.ForeColor = Color.DarkSlateGray;
            this.lblResult.BorderStyle = BorderStyle.FixedSingle;

            // Add controls to Form
            this.Controls.Add(this.grpTripDetails);
            this.Controls.Add(this.btnCalculateUSD);
            this.Controls.Add(this.btnConvertMetric);
            this.Controls.Add(this.lblResult);
        }

        // --- EVENT HANDLERS ---

        private void btnCalculateUSD_Click(object sender, EventArgs e)
        {
            // 2 sets of conditional statements
            if (ValidateInputs(txtDistance.Text, txtGasPrice.Text, txtEfficiency.Text))
            {
                // Parse inputs
                double dist = double.Parse(txtDistance.Text);
                double price = double.Parse(txtGasPrice.Text);
                double mpg = double.Parse(txtEfficiency.Text);

                if (dist > 0 && price > 0 && mpg > 0)
                {
                    // Call Custom Function 1: GetGallonsNeeded
                    double gallons = GetGallonsNeeded(dist, mpg);

                    // Call Custom Function 2: CalculateTotalCost
                    double totalCost = CalculateTotalCost(gallons, price);

                    lblResult.Text = $"Trip Report:\n" +
                                     $"Fuel Needed: {gallons:F2} gallons\n" +
                                     $"Total Cost: ${totalCost:F2}";
                    lblResult.ForeColor = Color.DarkGreen;
                }
                else
                {
                    lblResult.Text = "Error: Values must be positive.";
                    lblResult.ForeColor = Color.Red;
                }
            }
            else
            {
                lblResult.Text = "Error: Please enter valid numbers.";
                lblResult.ForeColor = Color.Red;
            }
        }

        private void btnConvertMetric_Click(object sender, EventArgs e)
        {
            // Similar validation logic
            if (ValidateInputs(txtDistance.Text, txtGasPrice.Text, txtEfficiency.Text))
            {
                double miles = double.Parse(txtDistance.Text);
                double gallons = GetGallonsNeeded(miles, double.Parse(txtEfficiency.Text));

                // Call Custom Function 3: ConvertMilesToKm
                double km = ConvertMilesToKm(miles);

                // Call Custom Function 4: ConvertGallonsToLiters
                double liters = ConvertGallonsToLiters(gallons);

                lblResult.Text = $"Metric Conversion:\n" +
                                 $"Distance: {km:F2} km\n" +
                                 $"Fuel: {liters:F2} Liters";
                lblResult.ForeColor = Color.Blue;
            }
            else
            {
                lblResult.Text = "Error: Please enter valid numbers.";
                lblResult.ForeColor = Color.Red;
            }
        }

        // --- 4 Custom Functions with parameters and return types ---

        /// <summary>
        /// Function 1: Calculates gallons required based on distance and efficiency.
        /// Returns a double (not void).
        /// </summary>
        private double GetGallonsNeeded(double distanceMiles, double mpg)
        {
            // Simple division logic
            return distanceMiles / mpg;
        }

        /// <summary>
        /// Function 2: Calculates total cost based on gallons and price.
        /// Returns a double (not void).
        /// </summary>
        private double CalculateTotalCost(double gallons, double pricePerGallon)
        {
            // Simple multiplication logic
            return gallons * pricePerGallon;
        }

        /// <summary>
        /// Function 3: Converts standard miles to metric kilometers.
        /// Returns a double (not void).
        /// </summary>
        private double ConvertMilesToKm(double miles)
        {
            // 1 Mile = 1.60934 Kilometers
            return miles * 1.60934;
        }

        /// <summary>
        /// Function 4: Converts gallons to liters.
        /// Returns a double (not void).
        /// </summary>
        private double ConvertGallonsToLiters(double gallons)
        {
            // 1 Gallon = 3.78541 Liters
            return gallons * 3.78541;
        }

        /// <summary>
        /// Helper Function: Validates that three string inputs are numbers.
        /// Returns a bool (true/false).
        /// </summary>
        private bool ValidateInputs(string s1, string s2, string s3)
        {
            double d1, d2, d3;
            // Attempts to parse all three. Returns true only if ALL are valid numbers.
            bool v1 = double.TryParse(s1, out d1);
            bool v2 = double.TryParse(s2, out d2);
            bool v3 = double.TryParse(s3, out d3);

            return v1 && v2 && v3;
        }
    }
}

