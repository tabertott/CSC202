#nullable disable
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Assignment1_GUI
{

    public partial class TripCostForm : Form
    {
        // Defining GUI components
        private GroupBox grpTripDetails;
        private Label lblDistance;
        private TextBox txtDistance;
        private Label lblGasPrice;
        private TextBox txtGasPrice;
        private Button btnCalculate;
        private Button btnReset;
        private Label lblResult;

        public TripCostForm()
        {
            // Build the UI
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            // --- FORM SETUP ---
            this.Text = "Trip Cost Estimator v1.0";
            this.Size = new Size(400, 350);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.WhiteSmoke;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // --- COMPONENT 1: GROUPBOX ---
            this.grpTripDetails = new GroupBox();
            this.grpTripDetails.Text = "Trip Details";
            this.grpTripDetails.Location = new Point(20, 20);
            this.grpTripDetails.Size = new Size(340, 150);
            this.grpTripDetails.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);

            // --- COMPONENT 2: LABEL ---
            this.lblDistance = new Label();
            this.lblDistance.Text = "Distance (miles):";
            this.lblDistance.Location = new Point(20, 40);
            this.lblDistance.AutoSize = true;

            // --- COMPONENT 3: TEXTBOX ---
            this.txtDistance = new TextBox();
            this.txtDistance.Location = new Point(150, 37);
            this.txtDistance.Size = new Size(150, 23);

            // --- COMPONENT 4: LABEL ---
            this.lblGasPrice = new Label();
            this.lblGasPrice.Text = "Gas Price ($/gal):";
            this.lblGasPrice.Location = new Point(20, 80);
            this.lblGasPrice.AutoSize = true;

            // --- COMPONENT 5: TEXTBOX ---
            this.txtGasPrice = new TextBox();
            this.txtGasPrice.Location = new Point(150, 77);
            this.txtGasPrice.Size = new Size(150, 23);

            // Add inputs to the GroupBox
            this.grpTripDetails.Controls.Add(this.lblDistance);
            this.grpTripDetails.Controls.Add(this.txtDistance);
            this.grpTripDetails.Controls.Add(this.lblGasPrice);
            this.grpTripDetails.Controls.Add(this.txtGasPrice);

            // --- COMPONENT 6: BUTTON ---
            this.btnCalculate = new Button();
            this.btnCalculate.Text = "Calculate Cost";
            this.btnCalculate.Location = new Point(20, 190);
            this.btnCalculate.Size = new Size(160, 40);
            this.btnCalculate.BackColor = Color.LightSteelBlue;
            this.btnCalculate.FlatStyle = FlatStyle.Flat;
            this.btnCalculate.Click += new EventHandler(this.btnCalculate_Click);

            // --- COMPONENT 7: BUTTON ---
            this.btnReset = new Button();
            this.btnReset.Text = "Reset";
            this.btnReset.Location = new Point(200, 190);
            this.btnReset.Size = new Size(160, 40);
            this.btnReset.BackColor = Color.LightGray;
            this.btnReset.FlatStyle = FlatStyle.Flat;
            this.btnReset.Click += new EventHandler(this.btnReset_Click);

            // --- COMPONENT 8: LABEL (Result) ---
            this.lblResult = new Label();
            this.lblResult.Text = "Estimated Cost: $0.00";
            this.lblResult.Location = new Point(20, 250);
            this.lblResult.AutoSize = false;
            this.lblResult.Size = new Size(340, 40);
            this.lblResult.TextAlign = ContentAlignment.MiddleCenter;
            this.lblResult.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            this.lblResult.ForeColor = Color.DarkSlateGray;

            // Add main controls to Form
            this.Controls.Add(this.grpTripDetails);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.lblResult);
        }

        // Event Handlers
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Placeholder logic
            lblResult.Text = "Calculating...";
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            // Placeholder reset logic
            txtDistance.Text = "";
            txtGasPrice.Text = "";
            lblResult.Text = "Estimated Cost: $0.00";
        }
    }
}


