﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment5_Arrays
{
    public partial class ProjectTrackerForm : Form
    {

        // Add 2 arrays... different data types

        // Array 1: String array to hold project names
        private string[] projectNames = new string[10];

        // Array 2: Int array to hold priority levels
        private int[] projectPriorities = new int[10];

        // Tracks how many spots are currently filled
        private int currentCount = 0;

        public ProjectTrackerForm()
        {
            InitializeComponent();
        }

        // EVENT: ADD BUTTON CLICK 

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Handle expected errors/exceptions
            try
            {
                // 1. Check if array is full
                if (currentCount >= projectNames.Length)
                {
                    // Throw a custom exception if full
                    throw new IndexOutOfRangeException("Project list is full! Maximum 10 projects.");
                }

                // 2. Validate Input
                string nameInput = txtProjectName.Text;
                if (string.IsNullOrWhiteSpace(nameInput))
                {
                    MessageBox.Show("Please enter a valid project name.", "Input Error");
                    return;
                }

                // 3. Add to Arrays
                // currentCount: Index for the next empty spot
                projectNames[currentCount] = nameInput;
                projectPriorities[currentCount] = (int)numPriority.Value;

                // 4. Increment count
                currentCount++;

                // 5. Update UI
                UpdateProjectList();
                ClearInputs();
            }
            catch (IndexOutOfRangeException ex)
            {
                // Catch specific array error
                MessageBox.Show(ex.Message, "Array Full Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                // Catch any other unexpected error
                MessageBox.Show("An unexpected error occurred: " + ex.Message);
            }
        }

        // EVENT: REMOVE BUTTON CLICK

        private void btnRemove_Click(object sender, EventArgs e)
        {
            try
            {
                // Check if an item is selected in the ListBox
                int selectedIndex = lstProjects.SelectedIndex;

                if (selectedIndex == -1)
                {
                    MessageBox.Show("Please select a project to remove.", "Selection Error");
                    return;
                }

                // LOGIC: Remove item from array and shift everything up
                // Example: Remove index 2. Index 3 moves to 2, 4 moves to 3, etc.
                for (int i = selectedIndex; i < currentCount - 1; i++)
                {
                    projectNames[i] = projectNames[i + 1];
                    projectPriorities[i] = projectPriorities[i + 1];
                }

                // Clear the last duplicate slot
                projectNames[currentCount - 1] = null;
                projectPriorities[currentCount - 1] = 0;

                // Decrement the total count
                currentCount--;

                // Update UI
                UpdateProjectList();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error removing item: " + ex.Message);
            }
        }


        // Update UI
        private void UpdateProjectList()
        {
            // Clear the ListBox
            lstProjects.Items.Clear();

            // Loop through the arrays up to the current count
            // Use the array in application
            for (int i = 0; i < currentCount; i++)
            {
                string displayString = $"[Priority {projectPriorities[i]}] - {projectNames[i]}";
                lstProjects.Items.Add(displayString);
            }

            // Update status label
            lblStatus.Text = $"System Ready. {currentCount}/10 Slots Used.";
        }

        private void ClearInputs()
        {
            txtProjectName.Clear();
            numPriority.Value = 1;
            txtProjectName.Focus();
        }
    }
}


